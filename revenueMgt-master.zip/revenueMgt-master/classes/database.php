<?php
  $serverName="localhost";
  $dbname = "project";
  $user = "root";
  $dbpass = "NAME123";

?>
