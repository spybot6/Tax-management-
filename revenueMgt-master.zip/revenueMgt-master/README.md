# revenueMgt
Revenue Management System
//Objective
This is a revenue management application that caters for tax realization from citizens as well as management by the administrators of this application. The goal is for local governemnts to be able to generate tax from their citizens considering the ever increasing need for local governments to generate and manage revenue effectively.


//User Manual
import the MYSQL database which is project.php
and run the application on an http server using this route: http://localhost/RMS/index.php

The user routes are:
http://localhost/RMS/login.php for login and 
http://localhost/RMS/signup.php for signup

The adminstrator routes are: 
http://localhost/RMS/adminlogin.php for login and 
http://localhost/RMS/adminsignup.php for registration 


This application is open for contribution...
Davecode!
